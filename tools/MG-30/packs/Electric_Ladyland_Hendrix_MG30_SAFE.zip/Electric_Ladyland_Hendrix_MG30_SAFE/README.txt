Electric_Ladyland_Hendrix_MG30_SAFE

20 MG-30 .mg30patch files inspired by Jimi Hendrix / Electric Ladyland-era guitar colors.

Important:
These are SAFE template patches. They are cloned from a known editable MG-30 patch and only renamed.
This avoids the silent/non-editable patch problem. Use the notes below as QuickTone dialing targets after import.

Suggested global approach:
- Strat-style single coils if possible.
- Push mids, keep bass controlled.
- Use fuzz/drive, wah, octave/pitch, vibe/chorus, spring/plate, and short tape/digital delay depending on the preset.
- Use guitar volume knob: Hendrix tones clean up from the instrument.

01. 01_VOODOO-CHLD.mg30patch / VOODOO-CHLD: Wah/fuzz lead. Try EFX fuzz/drive, wah on, delay short, spring/plate low.
02. 02_CROSSTOWN.mg30patch / CROSSTOWN: Bright Strat rhythm crunch, tight room, bridge pickup bite.
03. 03_WATCHTOWER.mg30patch / WATCHTOWER: Sustained lead voice, mid-forward amp, delay low, reverb medium.
04. 04_GYPSY-EYES.mg30patch / GYPSY-EYES: Fast psychedelic rhythm, trem/vibe optional, crisp pick attack.
05. 05_BURN-LAMP.mg30patch / BURN-LAMP: Clean-to-breakup ballad tone, neck pickup, warm reverb.
06. 06_1983-WASH.mg30patch / 1983-WASH: Ambient underwater clean: chorus/vibe, long reverb, gentle delay.
07. 07_MERMAN-VIBE.mg30patch / MERMAN-VIBE: Uni-Vibe style swirl, slower rate, wet but not washed out.
08. 08_HOUSE-FUZZ.mg30patch / HOUSE-FUZZ: Fuzz Face style lead, guitar volume rolled back for cleanup.
09. 09_PURPLE-HAZE.mg30patch / PURPLE-HAZE: Octavia-ish fuzz idea: octave/pitch if available, nasty upper mids.
10. 10_FOXY-LADY.mg30patch / FOXY-LADY: Heavy riff fuzz, neck/bridge blend feel, low delay.
11. 11_LITTLE-WING.mg30patch / LITTLE-WING: Glass clean chord melody, compression light, spring/plate gentle.
12. 12_WIND-CRIES.mg30patch / WIND-CRIES: Soft clean blues, round top, very touch-sensitive.
13. 13_RED-HOUSE.mg30patch / RED-HOUSE: Blues lead: warm amp breakup, no heavy modulation.
14. 14_FIRE-STOMP.mg30patch / FIRE-STOMP: Fast garage-rock crunch, dry and direct.
15. 15_CASTLES-SAND.mg30patch / CASTLES-SAND: Clean psychedelic rhythm, phase/vibe subtle, bright reverb.
16. 16_IF-6-9.mg30patch / IF-6-9: Loose fuzz rhythm, not too polished, big mids.
17. 17_STAR-SPANG.mg30patch / STAR-SPANG: Feedback/noise performance patch idea, wah/fuzz/manual expression.
18. 18_BOLD-AS-LOVE.mg30patch / BOLD-AS-LOVE: Expressive lead, medium gain, delay/reverb for bloom.
19. 19_AXIS-CLEAN.mg30patch / AXIS-CLEAN: Clean Strat foundation, usable base for chordal intro tones.
20. 20_ELECTRIC-SKY.mg30patch / ELECTRIC-SKY: Wide psychedelic lead: vibe, delay, and fuzz staged lightly.