Consolers_Lonely_MG30_RIG

20 NUX MG-30 .rig presets inspired by The Raconteurs - Consolers of the Lonely.
Import the .rig files into QuickTone/MG-30 one by one.

Scene map:
A = main rhythm
B = lead / boost / bigger chorus
C = clean, acoustic, or alternate verse color

These are playable approximations, not official artist patches.

01. 01_CNSLR-STOMP.rig - Consoler title-track staccato swagger
02. 02_SALUTE-FUZZ.rig - Salute Your Solution garage fuzz
03. 03_DONT-PIANO.rig - You Don't Understand Me broken piano edge
04. 04_OLD-ENOUGH.rig - Old Enough folk-country jangle
05. 05_SPUR-HORNS.rig - The Switch and the Spur western echo
06. 06_HOLD-UP-OD.rig - Hold Up tweaked overdriven licks
07. 07_TOP-SLIDE.rig - Top Yourself slide/banjo muscle
08. 08_MANY-BLACK.rig - Many Shades of Black Memphis ache
09. 09_FIVE-FIVE.rig - Five on the Five Icky-ish flourish
10. 10_ATTENTION.rig - Attention thick modern rock
11. 11_BLANKET-RIFF.rig - Pull This Blanket Off loose 70s riff
12. 12_RICH-KID.rig - Rich Kid Blues small-to-large
13. 13_STONES-BRST.rig - These Stones Will Shout acoustic burst
14. 14_CAROLINA.rig - Carolina Drama country-blues smolder
15. 15_COPPER-JET.rig - Copper Jet P90 crunch
16. 16_BIGMUFF-WHT.rig - Big Muff White-style sustain
17. 17_WHAMMY-OCT.rig - Whammy/octave solo color
18. 18_MEMPHIS-BAL.rig - Memphis horn ballad support
19. 19_BARN-BLUES.rig - Barn-room blues crunch
20. 20_TARANTINO.rig - Tiny-budget western soundtrack