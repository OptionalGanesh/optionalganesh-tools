Consolers_Lonely_MG30_MG30PATCH_V2

20 NUX MG-30 .mg30patch presets inspired by The Raconteurs - Consolers of the Lonely.
Import the .mg30patch files into QuickTone/MG-30 one by one.

Scene map:
A = main rhythm
B = lead / boost / bigger chorus
C = clean, acoustic, or alternate verse color

These are playable approximations, not official artist patches.
Container format matched from a real MG-30 pedal export: 9902 bytes, 0x8e-byte scene stride, original scaffold preserved.

01. 01_CNSLR-STOMP.mg30patch - Consoler title-track staccato swagger
02. 02_SALUTE-FUZZ.mg30patch - Salute Your Solution garage fuzz
03. 03_DONT-PIANO.mg30patch - You Don't Understand Me broken piano edge
04. 04_OLD-ENOUGH.mg30patch - Old Enough folk-country jangle
05. 05_SPUR-HORNS.mg30patch - The Switch and the Spur western echo
06. 06_HOLD-UP-OD.mg30patch - Hold Up tweaked overdriven licks
07. 07_TOP-SLIDE.mg30patch - Top Yourself slide/banjo muscle
08. 08_MANY-BLACK.mg30patch - Many Shades of Black Memphis ache
09. 09_FIVE-FIVE.mg30patch - Five on the Five Icky-ish flourish
10. 10_ATTENTION.mg30patch - Attention thick modern rock
11. 11_BLANKET-RIFF.mg30patch - Pull This Blanket Off loose 70s riff
12. 12_RICH-KID.mg30patch - Rich Kid Blues small-to-large
13. 13_STONES-BRST.mg30patch - These Stones Will Shout acoustic burst
14. 14_CAROLINA.mg30patch - Carolina Drama country-blues smolder
15. 15_COPPER-JET.mg30patch - Copper Jet P90 crunch
16. 16_BIGMUFF-WHT.mg30patch - Big Muff White-style sustain
17. 17_WHAMMY-OCT.mg30patch - Whammy/octave solo color
18. 18_MEMPHIS-BAL.mg30patch - Memphis horn ballad support
19. 19_BARN-BLUES.mg30patch - Barn-room blues crunch
20. 20_TARANTINO.mg30patch - Tiny-budget western soundtrack