Electric_Ladyland_Hendrix_MG30_SCENES_SAFE

20 MG-30 .mg30patch files inspired by Jimi Hendrix / Electric Ladyland-era guitar colors.

Important:
These are SAFE scene-template patches. They are cloned from a known editable MG-30 patch and only scene labels are renamed.
This avoids the silent/non-editable patch problem. Each patch has an A/B/C performance plan below.

Suggested global approach:
- Strat-style single coils if possible.
- Push mids, keep bass controlled.
- Use fuzz/drive, wah, octave/pitch, vibe/chorus, spring/plate, and short tape/digital delay depending on the preset.
- Use guitar volume knob: Hendrix tones clean up from the instrument.

01. 01_VOODOO-CHLD.mg30patch / VOODOO-CHLD
    A VOODOO-RHY - dry riff base with wah off, edge-of-breakup amp
    B VOODOO-WAH - wah/fuzz lead, short delay, more level
    C VOODOO-SKY - psychedelic wash with vibe or delay for outro noise
02. 02_CROSSTOWN.mg30patch / CROSSTOWN
    A CROSS-RIFF - bright Strat rhythm crunch
    B CROSS-LEAD - tighter solo boost with extra mids
    C CROSS-CLEAN - rolled-back guitar volume clean rhythm
03. 03_WATCHTOWER.mg30patch / WATCHTOWER
    A WATCH-RHY - urgent rhythm with controlled bass
    B WATCH-LEAD - sustained mid-forward lead
    C WATCH-ECHO - echo-heavy arpeggio/bridge color
04. 04_GYPSY-EYES.mg30patch / GYPSY-EYES
    A GYPSY-RHY - fast clipped rhythm
    B GYPSY-FUZZ - fuzzed single-note lines
    C GYPSY-VIBE - vibe/phase texture for psychedelic sections
05. 05_BURN-LAMP.mg30patch / BURN-LAMP
    A BURN-CLEAN - warm ballad clean
    B BURN-BLOOM - reverb/delay bloom for fills
    C BURN-DRIVE - breakup lead with neck pickup
06. 06_1983-WASH.mg30patch / 1983-WASH
    A 1983-CLEAN - glassy underwater clean
    B 1983-DEEP - chorus/vibe deeper scene
    C 1983-SKY - long reverb/delay ambient lead
07. 07_MERMAN-VIBE.mg30patch / MERMAN-VIBE
    A MERMAN-RHY - gentle clean base
    B MERMAN-VIBE - Uni-Vibe swirl
    C MERMAN-SEA - wetter oceanic scene with reverb up
08. 08_HOUSE-FUZZ.mg30patch / HOUSE-FUZZ
    A HOUSE-CLN - guitar-volume-cleaned rhythm
    B HOUSE-FUZZ - Fuzz Face style main tone
    C HOUSE-LEAD - louder singing lead
09. 09_PURPLE-HAZE.mg30patch / PURPLE-HAZE
    A HAZE-RIFF - riff crunch
    B HAZE-OCT - Octavia/pitch-fuzz idea
    C HAZE-SOLO - nasty upper-mid lead
10. 10_FOXY-LADY.mg30patch / FOXY-LADY
    A FOXY-RIFF - heavy riff
    B FOXY-FUZZ - thicker fuzz rhythm
    C FOXY-SOLO - wide lead with delay low
11. 11_LITTLE-WING.mg30patch / LITTLE-WING
    A WING-CLN - glass clean intro/chords
    B WING-CHORD - compressed chord melody
    C WING-LEAD - soft singing lead with spring/plate
12. 12_WIND-CRIES.mg30patch / WIND-CRIES
    A WIND-CLEAN - soft clean blues
    B WIND-FILL - fills with tiny delay
    C WIND-SOLO - rounded lead, low gain
13. 13_RED-HOUSE.mg30patch / RED-HOUSE
    A RED-RHY - blues comping
    B RED-LEAD - warm lead breakup
    C RED-RAW - rawer no-mod scene for dynamics
14. 14_FIRE-STOMP.mg30patch / FIRE-STOMP
    A FIRE-RIFF - dry fast garage rhythm
    B FIRE-BRST - brighter burst/chorus scene
    C FIRE-LEAD - cutting lead
15. 15_CASTLES-SAND.mg30patch / CASTLES-SAND
    A SAND-CLN - clean psych rhythm
    B SAND-PHASE - phase/vibe shimmer
    C SAND-LEAD - bright melodic lead
16. 16_IF-6-9.mg30patch / IF-6-9
    A IF69-RHY - loose rhythm
    B IF69-FUZZ - fuzzed wide chords
    C IF69-NOISE - noisy outro/feedback scene
17. 17_STAR-SPANG.mg30patch / STAR-SPANG
    A STAR-CLEAN - anthem clean base
    B STAR-WAH - wah/fuzz expression scene
    C STAR-NOISE - feedback/noise performance scene
18. 18_BOLD-AS-LOVE.mg30patch / BOLD-AS-LOVE
    A BOLD-RHY - expressive rhythm
    B BOLD-LEAD - medium gain lead
    C BOLD-SKY - delay/reverb bloom for outro
19. 19_AXIS-CLEAN.mg30patch / AXIS-CLEAN
    A AXIS-CLN - clean Strat foundation
    B AXIS-COMP - compressed chord scene
    C AXIS-EDGE - slightly driven edge
20. 20_ELECTRIC-SKY.mg30patch / ELECTRIC-SKY
    A SKY-RHY - wide rhythm base
    B SKY-VIBE - vibe/delay psychedelic scene
    C SKY-FUZZ - fuzz lead staged lightly