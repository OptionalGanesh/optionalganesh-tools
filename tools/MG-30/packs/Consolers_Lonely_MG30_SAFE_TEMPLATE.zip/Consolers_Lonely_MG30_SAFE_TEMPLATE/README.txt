Consolers_Lonely_MG30_SAFE_TEMPLATE

Smoke-test pack for MG-30 import/editability.
Every .mg30patch is cloned from a known local working patch:
/Users/optionalganesh/Downloads/tools/mayer_blues.mg30patch

Only the scene names were changed. If these sound and remain editable, this is the safe base for the next tone-varied generation.

01. 01_CNSLR-STOMP.mg30patch - CNSLR-STOMP
02. 02_SALUTE-FUZZ.mg30patch - SALUTE-FUZZ
03. 03_DONT-PIANO.mg30patch - DONT-PIANO
04. 04_OLD-ENOUGH.mg30patch - OLD-ENOUGH
05. 05_SPUR-HORNS.mg30patch - SPUR-HORNS
06. 06_HOLD-UP-OD.mg30patch - HOLD-UP-OD
07. 07_TOP-SLIDE.mg30patch - TOP-SLIDE
08. 08_MANY-BLACK.mg30patch - MANY-BLACK
09. 09_FIVE-FIVE.mg30patch - FIVE-FIVE
10. 10_ATTENTION.mg30patch - ATTENTION
11. 11_BLANKET-RIFF.mg30patch - BLANKET-RIFF
12. 12_RICH-KID.mg30patch - RICH-KID
13. 13_STONES-BRST.mg30patch - STONES-BRST
14. 14_CAROLINA.mg30patch - CAROLINA
15. 15_COPPER-JET.mg30patch - COPPER-JET
16. 16_BIGMUFF-WHT.mg30patch - BIGMUFF-WHT
17. 17_WHAMMY-OCT.mg30patch - WHAMMY-OCT
18. 18_MEMPHIS-BAL.mg30patch - MEMPHIS-BAL
19. 19_BARN-BLUES.mg30patch - BARN-BLUES
20. 20_TARANTINO.mg30patch - TARANTINO